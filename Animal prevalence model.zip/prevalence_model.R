# Load required libraries
library( tidyverse )
library( here )
library( readxl )
library( rstan )
library( tidybayes )
library( patchwork )
library( knitr )
library( furrr )
library( writexl )
library( scales )
library( glue )

setwd( here("animal prevalence"))

# If you get annoying popups about RTools/build tools, uncomment the next line
#options(buildtools.check = NULL)
options(mc.cores = parallel::detectCores())
rstan_options(auto_write = TRUE)

plan(multisession, workers = 4 )

source( "functions.R")

modeltype <- "SIS"
testtype  <- "Indirect"
filepath <- here("animal prevalence", "output", 
                 str_c(testtype,"_", modeltype ))
if( !dir.exists(filepath)) dir.create(filepath, recursive = TRUE)

read_animals() %>% 
  filter( !is.na(n_tot), !is.na(n_pos) ) %>% 
  write_xlsx( str_c( filepath, "input_data_collated.xlsx" ))


df_animals <- read_animals() %>% 
  filter( !is.na(n_tot), !is.na(n_pos),
          test == testtype,
          !(species %in% c("Buffalo", "Cattle", "Equids")),
          region != "Mix" ) %>% 
  mutate( age_high= ifelse( age_low==age_high, age_high*1.1, age_high )) %>%
  mutate( age_high= ifelse( age_low==age_high & age==age_high, age_high*1.1, age_high )) %>%
  mutate( age_low = ifelse( age_low==age_high & age==age_low,  age_low*0.9, age_low )) %>%
  mutate( age = ifelse( age_low==age, (age_high+age_low)/2, age )) %>%
  mutate( age = ifelse( age_high==age, (age_high+age_low)/2, age )) %>%
  group_by( species ) %>% 
  mutate( age_max = max(age_high )) %>% 
  ungroup() %>% 
  mutate( across( c(age, age_low, age_high), ~.x/age_max) ) %>% 
  droplevels()

#
# Stan model for prevalence in animals and regions, censored age
#

m_prevalence <- stan( file="prevalence.stan",
                      #init = inits,
                      iter=3000,
                      seed=3141,
                      data=compose_data( df_animals,
                                         use_sis_model=(modeltype=="SIS")),
                      control = list(adapt_delta = 0.99,
                                     max_treedepth=13 ) )

m_prevalence <- readRDS( file= file.path(filepath, "m_prevalence.RData"))    

my_pars <- c( "lambda_region[1]", "lambda_region[2]",
              "lambda_species[1]",
              "lambda_baseline",
              "sigma_lambda_region",
              "sigma_lambda_species",
              "sigma_lambda_sample_type",
              "lp__")

if( modeltype!="SI") my_pars <- c(my_pars,
                                  "gamma_baseline",
                                  "sigma_gamma_species[1]",
                                  "gamma_species[1,1]",
                                  "gamma_species[1,2]")


png( file.path(filepath,"traceplot.png" ) )
print(traceplot(m_prevalence, pars = my_pars, inc_warmup=FALSE ))
dev.off()

# sink( file.path(filepath, "loo.txt"))
# print(loo::loo(m_prevalence, cores = 4 ))
# sink()

if( modeltype=="SI"){
  df_prevalence <- m_prevalence %>% 
    recover_types( df_animals ) %>% 
    spread_draws( lambda[species, region, sample_type],
                  lambda_baseline,
                  lambda_species[species],
                  lambda_region[region],
                  lambda_outdoor[outdoor],
                  lambda_sample_type[sample_type],
                  sigma_lambda_outdoor,
                  sigma_lambda_region,
                  sigma_lambda_sample_type,
                  sigma_lambda_species) 
}else{
  df_prevalence <- m_prevalence %>% 
    recover_types( df_animals ) %>% 
    spread_draws( lambda_baseline,
                  lambda_species[species],
                  lambda_region[region],
                  lambda_sample_type[sample_type],
                  lambda_outdoor[outdoor],
                  sigma_lambda_region,
                  sigma_lambda_outdoor,
                  sigma_lambda_species,
                  sigma_lambda_sample_type,
                  gamma_baseline[0],
                  gamma_species[0,species],
                  sigma_gamma_species[0]
                  ) %>% 
    left_join( df_animals %>% select( species, age_max) %>% unique() ) %>%
    mutate( across( contains("gamma"), as.numeric )) %>%
    # Rescale sigma because it had an exp link.
    #mutate( across( starts_with("sigma_"), exp ) ) %>% 

    mutate( lambda = exp(lambda_baseline + 
                  sigma_lambda_region * lambda_region +
                  sigma_lambda_species * lambda_species +
                  sigma_lambda_sample_type * lambda_sample_type +
                  sigma_lambda_outdoor * lambda_outdoor ),
            lambda.qmra = exp(lambda_baseline + 
                   sigma_lambda_region * lambda_region +
                   sigma_lambda_species * lambda_species +
                   sigma_lambda_outdoor * lambda_outdoor ),
            gamma = exp( gamma_baseline + sigma_gamma_species*gamma_species ) ) %>% 
    # Rescale all rates to real maximum age
    mutate( across( c(lambda,lambda.qmra,gamma), ~.x / age_max ) ) %>% 
    #  Rescale lambda_ and gamma_
    # variables because of how they are in the formula.
    mutate( across( starts_with(c("lambda_", "gamma_" )), exp ) ) %>% 
    ungroup()
}

saveRDS( df_prevalence, file= file.path(filepath, "df_prevalence.RData"))
saveRDS( m_prevalence, file= file.path(filepath, "m_prevalence.RData"))

df_prevalence <- readRDS( file.path(filepath, "df_prevalence.RData"))

df_prevalence %>%
  group_by( species ) %>% 
  mean_qi( lambda_species )  

df_prevalence %>%
  group_by( outdoor ) %>% 
  mean_qi( lambda_outdoor )  

df_prevalence %>%
  group_by( region ) %>% 
  mean_qi( lambda_region )  

df_prevalence %>%
  mean_qi( lambda_baseline )  

df_prevalence %>%
  mean_qi( gamma_baseline ) 

df_age <- m_prevalence %>% 
  recover_types( df_animals ) %>% 
  spread_draws( age_raw[i] ) %>% 
  group_by(i) %>% 
  summarize( age_raw=mean(age_raw), .groups="drop") %>% 
  cbind( ind=df_animals$ind ) %>% 
  left_join( df_animals ) %>% 
  mutate( agedist = (age_raw*(age_high-age_low) + age_low )*age_max) %>% 
  select( ind, agedist )


df_age %>% 
  left_join( df_animals ) %>% 
  mutate( ind=as.factor(ind),
          ind=fct_reorder(ind, age)) %>% 
  ggplot() +
    geom_errorbar( aes(xmin=age_low*age_max,xmax=age_high*age_max, y=ind) ) +
    geom_point( aes( x=age*age_max, y=ind), color="black", size=2 ) +
    geom_point( aes( x=agedist, y=ind), color="blue", size=2 ) +
    facet_wrap( vars(species), scale="free" )
ggsave(file.path(filepath, "age_shift.png"), 
       width=30, height=30, units="cm" )


plot_hyperparameters( df_prevalence )
ggsave( file.path(filepath, "hyperparameters.png"), 
              width=15, height=10, units="cm" )

plot_posteriors( df_prevalence )
ggsave( file.path(filepath, "posteriors.png"), 
        width=25, height=20, units="cm" )

p <- df_prevalence %>%
  plot_dynamics_by_species( df_animals, 
                            df_age, 
                            ifelse( modeltype=="SIS", sis, sir) )
map(p, print)


f <- function(x){ cbind(mean_qi(x,p), age=mean(x$age)  ) }

df_meanage <- df_animals %>% group_by(species) %>% 
  summarize( age=mean( age_max * age) )

df_prevalence %>%
  group_by( outdoor ) %>% 
  group_walk( ~{
    .x %>% 
      left_join( df_meanage, by = c("species") ) %>% 
      mutate( p = sis(lambda, gamma, age  )) %>%
      group_by( species) %>%
      mean_qi( p ) %>% 
      left_join( df_meanage, by="species" ) %>%
      mutate( p = sprintf( "%1.1f%% (%1.1f%%, %1.1f%%) [%1.1f]", 100*p, 100*.lower, 100*.upper, age)) %>% 
      select( species, p ) %>% 
      knitr::kable( format="html") %>% 
      cat(file=file.path(filepath, glue("estimates_{.y[[1]]}.html")))})

# Age stratified over everything. If no age available, use species mean.
df_meanage <- df_animals %>%
  select( species, region, sample_type, outdoor, age, age_max ) %>% 
  tidyr::complete( species, region, sample_type, outdoor, fill=list(age=NA, age_max=NA ) ) %>% 
  group_by(species ) %>%
  mutate( species_mean = mean(age_max * age , na.rm=TRUE )) %>%
  group_by(species, region, sample_type, outdoor, species_mean ) %>% 
  summarize( age1=mean( age_max * age), .groups="drop" ) %>% 
  mutate( age = if_else( is.na(age1), species_mean, age1), 
          age_str = if_else( is.na(age1), sprintf("%1.1f*", species_mean), sprintf("%1.1f", age1) ) )

df_prevalence %>%
  left_join( df_meanage,  by = c("species", "region", "sample_type", "outdoor") ) %>% 
  filter( outdoor != "unknown" ) %>% 
  group_by( sample_type ) %>% 
  group_walk( ~{
    t1 <- .x %>% 
      mutate( p = sis(lambda, gamma, age)) %>%
      group_by( species, outdoor, region ) %>%
      mean_qi( p ) %>%
      left_join( df_meanage %>% filter( sample_type==.y[[1]]), by = c("species", "outdoor", "region") ) %>%
      mutate( p = sprintf( "%1.1f%% (%1.1f%%, %1.1f%%) [%s]", 100*p, 100*.lower, 100*.upper, age_str)) %>%
      select( species, outdoor, region, p) %>%
      pivot_wider( names_from=region, values_from=p)
    
    t2 <- .x %>%
      mutate( p = sis(lambda, gamma, age)) %>%
      group_by( species, outdoor ) %>%
      mean_qi( p ) %>%
      left_join( df_meanage %>% filter( sample_type==.y[[1]]), by = c("species", "outdoor" ) ) %>%
      mutate( p = sprintf( "%1.1f%% (%1.1f%%, %1.1f%%)", 100*p, 100*.lower, 100*.upper )) %>%
      select( species, outdoor, Europe=p)

    inner_join(t1, t2) %>% 
      unique() %>% 
      knitr::kable( format="html") %>%
      cat( file=file.path(filepath, glue("estimates_region_{.y[[1]]}.html")))})

#
# Write file for QMRA
#

df_meanage_qmra <- rbind(
  df_meanage %>% 
    select( region, outdoor, species, age ),
  df_meanage %>% 
    select( region, outdoor ) %>% 
    unique() %>% 
    expand_grid( species=c("Goat", "Sheep")) %>% 
    mutate( age=1 ))


df_prevalence_qmra <- df_prevalence %>%
  select( species, region, outdoor, lambda.qmra, gamma ) %>% 
  left_join( df_meanage_qmra,  by = c("species", "region", "outdoor") ) %>% 
  filter( outdoor != "unknown" ) %>% 
  mutate( p = sis(lambda.qmra, gamma, age),
          species = as.character( species ),
          species = ifelse( species=="Goat"  & age==1, "Kid", species ),
          species = ifelse( species=="Sheep" & age==1, "Lamb", species ),
          species = as.factor(species )) %>% 
  select( species, outdoor, region, p ) %>% 
  droplevels()

saveRDS( df_prevalence_qmra, file= file.path(filepath, "df_prevalence_qmra.RData"))


#
# Direct Methods
#
df_direct <- read_animals() %>% 
  filter( !is.na(n_tot), !is.na(n_pos),
          test == "Direct",
          region != "Mix" ) %>% 
  group_by( region, species, sample_type ) %>% 
  summarize( n_tot=round(sum(weight*n_tot)), n_pos=round(sum(weight*n_pos)), .groups="drop") %>% 
  mutate( prev = n_pos/n_tot )

df_direct  %>% 
  pmap_dfr( .f= function(n_pos, n_tot,region,species,sample_type, prev){
    t <-binom.test(n_pos,n_tot)$conf.int 
    data.frame(region,species,sample_type, 
               prev=sprintf( "%1.2f%% (%1.2f%%,%1.2f%%)", 100*prev, low=100*t[[1]], high=100*t[[2]]), n_tot)
  }) %>% 
  arrange( species )%>% 
  knitr::kable( format="html") %>% 
  cat( file=file.path(filepath,"estimates_direct.html"))

rbind(
  df_direct %>% group_by(species, sample_type ) %>% 
    summarize( n_tot=sum(n_tot), n_pos=sum(n_pos), prev=mean(prev), .groups="drop"  ) %>% 
    mutate( region="Europe"),
  df_direct )%>% 
  pmap_dfr( .f= function(n_pos, n_tot,region,species,sample_type, prev){
    t <-binom.test(n_pos,n_tot)$conf.int 
    data.frame(region,species,sample_type, 
               prev=prev, low=t[[1]], high=t[[2]])}) %>% 
  mutate( region = as.factor(region),
          region = fct_relevel( region, "East", "West", "North", "Southeast", "Southwest")) %>% 
  ggplot() +
  geom_point(aes(x=prev, y=species, color=sample_type ),
             position=position_dodge(width=0.5)) +
  geom_errorbar( aes(x=prev, xmin=low, xmax=high, y=species, color=sample_type ),
                   position=position_dodge(width=0.5)) +
    facet_wrap( vars(region)) +
    scale_x_continuous( "Prevalence", labels=scales::percent, breaks=seq(0,1.1, by=0.2) ) +
    scale_color_discrete( "Sample Type")
ggsave( file.path(filepath, "/directmethods.png"), 
        width=18, height=15, units="cm" )

df_direct_qmra <- df_direct %>% group_by( species ) %>% 
  summarize( n_tot = sum(n_tot), n_pos=sum(n_pos), .groups = "drop" )

df_direct_qmra  %>% 
  filter( species %in% c("Cattle", "Equids", "Buffalo")) %>% 
  expand_grid( outdoor=c("indoor", "outdoor"), region=levels(df_prevalence_qmra$region)) %>% 
  droplevels() %>% 
  pmap_dfr( .f= function(n_pos, n_tot,region,species, outdoor ){
    data.frame(region,species, outdoor,
               p =rbeta( 1000, n_pos+1, n_tot-n_pos+1 ))}) %>% 
  saveRDS( file= file.path(filepath, "df_prevalence_direct_qmra.RData"))


