read_animals <- function(){
  tibble(
    files = list.files( "./data/", pattern=".*xlsx",
                        full.names=TRUE)) %>% 
    filter( !str_detect( files,".*~")) %>% 
    mutate( species = c("Buffalo", 
                        "Cattle", 
                        "Chicken_Hen_Turkey", 
                        "Duck_Goose", 
                        "Equids", 
                        "Felids", 
                        "Goat",
                        "Pig",
                        "Lagomorphs", 
                        "Sheep", 
                        "Wild_Birds", 
                        "Wild_Boar",
                        "Wild_Ruminants")
            ) %>% 
    pmap_dfr( 
      function( files, species){
        read_excel(files, trim_ws = TRUE) %>% 
          select( 
            n_pos = `Total number of positive animals (n)`,
            n_tot = `Total number of animals (N)`,
            test = `Type of detection`,
            sample_type = `Sample type`,
            region = `Region`,
            age_low = `Age - lower [years]`,
            age_high = `Age - upper [years]`,
            age_best = `Age - most probable [years]`,
            pop_id = `Population`,
            study = `Number of the article`,
            outdoor_tot = `Total number of animals that were or had access outdoors`,
            outdoor_pos = `Total number of positive animals that were or had access outdoors`
            ) %>% 
          mutate( species = species,
                  pop_id = as.character(pop_id),
                  study = as.factor( study ),
                  prev = n_pos/n_tot)}) %>% 
          mutate( across( c(test,region, species, sample_type), as.factor),
                  sample_type = fct_other(sample_type, 
                                          keep=c("Blood", "Meat juice", "Feces", "Muscle"))) %>% 
          mutate( indoor_pos = n_pos-outdoor_pos,
                  indoor_tot= n_tot-outdoor_tot,
                  unknown_pos = ifelse( is.na( outdoor_pos ) & !is.na(n_pos), n_pos, 0 ),
                  unknown_tot = ifelse( is.na( outdoor_tot ) & !is.na(n_tot), n_tot, 0 ) ) %>%
        select( region, species, test, sample_type,
              age_low, age_high, age=age_best,pop_id,
              prev, study,
              #n_tot, n_pos, # for outdoor use below
              outdoor_tot, outdoor_pos, indoor_pos, indoor_tot, unknown_pos, unknown_tot 
              ) %>%
        pivot_longer( c(outdoor_pos, outdoor_tot, indoor_pos, indoor_tot, unknown_pos, unknown_tot ),
                      names_to=c("outdoor", ".value"), names_sep="_" ) %>%
        mutate( outdoor=as.factor(outdoor)) %>%
        filter( tot > 0 ) %>%
        filter( !is.na(tot), !is.na(pos)) %>%
        rename( n_tot=tot, n_pos=pos ) %>%
    group_by( pop_id, species, region, test, sample_type,
              outdoor ) %>% 
    mutate( population_id = as.factor(as.character(cur_group_id())),
            weight = 1/n() ) %>% 
    ungroup() %>% 
    mutate( ind =1:n()) %>% 
    select(-pop_id ) %>%
    droplevels()
}

sir <- function(lambda, gamma=0, x){
  lambda*(exp(-lambda*x)-exp( -gamma*x) )/(gamma-lambda)
}

sis <- function(lambda, gamma, x){
  lambda*(1-exp( -(lambda+gamma) * x) )/(lambda+gamma)
}

plot_hyperparameters <- function( df_prevalence ){
 p1 <- df_prevalence %>% 
      ggplot() +
      stat_halfeye( aes(sigma_lambda_region), fill="green" ) +
      ggtitle( "Hyperparameters lambda region")
 p2 <- df_prevalence %>% 
      ggplot() +
      stat_halfeye( aes(sigma_lambda_species), fill="green" ) +
      ggtitle( "Hyperparameters lambda species")
 p3 <- df_prevalence %>% 
   ggplot() +
   stat_halfeye( aes(sigma_lambda_sample_type), fill="green" ) +
   ggtitle( "Hyperparameters lambda sample type")
 p4 <- df_prevalence %>% 
   ggplot() +
   stat_halfeye( aes(sigma_lambda_outdoor), fill="green" ) +
   ggtitle( "Hyperparameters lambda outdoor")
 p5 <- df_prevalence %>% 
   ggplot() +
   stat_halfeye( aes(sigma_gamma_species), fill="green" ) +
   ggtitle( "Hyperparameter sigma_gamma_species")

  if( modeltype=="SI"){  
    reduce( list(p1,p2,p3,p4), `+` ) + plot_layout( ncol=2 )
  }else{
    reduce( list(p1,p2,p3,p4,p5), `+` ) + plot_layout( ncol=2 )
  }
    
}

plot_posteriors <- function( df_prevalence ){

  p1 <- df_prevalence %>% 
    ggplot() +
      stat_halfeye( aes(lambda_baseline), fill="green" ) +
      scale_x_continuous( "Baseline Force of Infection") +
      ggtitle( "lambda baseline")
  p2 <- df_prevalence %>% 
    ggplot() +
      stat_gradientinterval( aes(lambda_region, y=region ),fill_type = "gradient" ) +
      scale_x_continuous( "Force of infection", limits=c(0,10) ) +
      ggtitle( "lambda region")
  p3 <- df_prevalence %>%
    ggplot() +
      stat_gradientinterval( aes(lambda_species, y=species),fill_type = "gradient" ) +
      scale_x_continuous( "Force of infection", limits=c(0,7.5) ) +
      ggtitle( "lambda species")
  p4 <- df_prevalence %>%
    ggplot() +
      stat_gradientinterval( aes(lambda_sample_type, y=sample_type),fill_type = "gradient" ) +
      scale_x_continuous( "Force of infection", limits=c(0,10) ) +
      ggtitle( "lambda sample_type")
  p5 <- df_prevalence %>%
    ggplot() +
    stat_gradientinterval( aes(lambda_outdoor, y=outdoor),fill_type = "gradient" ) +
    scale_x_continuous( "Force of infection", limits=c(0,5) ) +
    ggtitle( "lambda outdoor")
  p6 <- df_prevalence %>% 
    ggplot() +
      stat_halfeye( aes(gamma_baseline), fill="green" ) +
      scale_x_continuous( "Baseline reversion" ) +
      ggtitle( "gamma baseline")
  p7 <-df_prevalence %>% 
     ggplot() +
    stat_gradientinterval( aes(gamma_species, y=species ),fill_type = "gradient" ) +
      scale_x_continuous( "Reversion", limits=c(0,7) )
 
  if(modeltype == "SI" ){
    reduce( list(p1,p2,p3,p4,p5), `+` ) + plot_layout( ncol=3  )
  }else{
    reduce( list(p1,p2,p3,p4,p5,p6,p7), `+` ) + plot_layout( ncol=3  )
  }
}

plot_agedist <- function( df_age ){
  df_age %>%
    filter( ind %in% sample(1:max(.$ind), 10 )) %>% 
    ggplot() +
    stat_halfeye( aes(agedist, fill=as.factor(ind)) )
}


# Using estimated age
plot_dynamics_est_age <- function( df_animals, df_age, fun ){
  if( modeltype !="SI") {
    df_prevalence <- df_prevalence %>%
      group_by( region, species, sample_type) %>%  # outdoor ) %>%
      summarize( lambda = mean(lambda_baseline * 
                                      lambda_species * 
                                      lambda_region *
                                      lambda_sample_type #*
                                      #lambda_outdoor 
                               ), 
                  gamma=mean(gamma), .groups="drop" ) %>%
      expand_grid( x=0:20 ) %>%
      mutate(p=fun(lambda, gamma, x) )
  }else{
    df_prevalence <- df_prevalence %>%
      group_by( region, species, sample_type ) %>% #, outdoor ) %>%
      summarize( lambda = mean( exp(lambda_baseline + 
                                      lambda_species + 
                                      lambda_region + 
                                      #lambda_outdoor +
                                      #lambda_population +
                                      lambda_sample_type)), 
                 .groups="drop" ) %>%
      expand_grid( x=0:20 ) %>%
      mutate(p=fun(lambda, 0, x) )
  }
  
  df_animals %>%
    left_join( df_age) %>% 
    mutate( 
      ymax=qbinom( 0.975, size=n_tot, prob=prev )/n_tot,
      ymin=qbinom( 0.025, size=n_tot, prob=prev )/n_tot) %>%
    ggplot( ) + 
    scale_x_continuous( "Age", limits=c(  0,20)) +
    scale_y_continuous( "Prevalence") +
    ggtitle( "The data and fit, estimated age" ) +
    geom_rect( aes( xmin=age_low, xmax=age_high, ymin=ymin, ymax=ymax, color=sample_type ),
               fill=NA ) +
    geom_point( aes(x=agedist, y=prev, color=sample_type ), size=1 )+
    geom_line( data=df_prevalence,
               mapping=aes(x, p, color=sample_type), size=0.5) +
    facet_grid( vars(region), vars(species), scale="free") +
    scale_size(range = c(0, 5))
}


plot_dynamics_by_species <- function( df_prevalence, df_animals, df_age, fun ){
  df_maxage <- df_animals %>%
    select( species, age_max ) %>% 
    unique() %>% 
    pmap_dfr( .f=function(age_max,...){
      tibble( ..., x=seq( 0, age_max*1.1, length.out=20 ))})
  
  if( modeltype =="SI") {
    df_prevalence$gamma <- 0
  }
  
  df_prevalence <- df_prevalence %>% 
    group_by( species, region, sample_type, outdoor ) %>% 
    sample_draws( 100 ) %>%
    left_join( df_maxage, by="species" ) %>%
    mutate(p=fun(lambda, gamma, x) )
  
  df_animals %>%
    left_join( df_age, by="ind" ) %>% 
    mutate( across( c(age, age_low, age_high), ~.x*age_max ) ) %>%
    group_by(species) %>% 
    group_split() %>% 
    future_map( .f=function(x){  
      the_species <- x$species[[1]]
      
      p <- x %>% ggplot( ) + 
        scale_x_continuous( "Age", limits=c(  0, x$age_max[[1]]*1.1 )) +
        scale_y_continuous( "Prevalence",  breaks=seq(0,1,by=0.2), labels=scales::percent ) +
        coord_cartesian( ylim=c(0,1) ) +
        # Data
        geom_segment( aes( x=age_low, xend=age_high, y=prev, yend=prev), color="gray", alpha=0.5)+
        geom_point( aes( x=age, y=prev, size=n_tot ), color="gray" )+
        # Model fit
        stat_lineribbon( data=df_prevalence %>% filter(species==the_species) %>% droplevels(), 
                   mapping=aes(x, p, 
                               group=interaction(sample_type, species, region, outdoor), 
                               color=sample_type, fill=sample_type ), 
                   .width=0.95, point_interval=median_hdi, alpha=0.3 ) +
        geom_point( aes(x=agedist, y=prev, color=sample_type  ) )+
        facet_grid( rows=vars(region), cols=vars(outdoor) ) +
        ggtitle( str_c( the_species, ": The data and fit, estimated age" ))
      ggsave(file.path(filepath, str_c("byspecies_", the_species, ".png")), plot=p)
      return(p)
    })
}

inits = function() {
  list(
    # sigma_lambda_region = 0.5,
    # sigma_lambda_species = 1,
    # sigma_lambda_sample_type = 0.1,
    # sigma_lambda_outdoor = 1,
    # sigma_gamma_species = array( 1, dim=(modeltype!="SI")),
    # mu_gamma_species = array( -1, dim=(modeltype!="SI")),
    lambda_baseline = 1,
    gamma_baseline = array( 0.5, dim=(modeltype!="SI"))
    # lambda_region = rep(log(1), length(levels(df_animals$region))),
    # lambda_species = rep(log(1), length(levels(df_animals$species))),
    # gamma_species = matrix(-1, nrow=(modeltype!="SI"), ncol=length(levels(df_animals$species))),
    # lambda_sample_type = rep(log(1), length(levels(df_animals$sample_type))),
    # lambda_outdoor = array( rep(0, length(levels(df_animals$outdoor)))),
    # lambda_population = array( rep(0, length(levels(df_animals$population_id)))),
    # lambda_population_raw = array( rep(1/length(levels(df_animals$population_id)), length(levels(df_animals$population_id))-1))
    
    # lambda_region_raw = rep(0, length(levels(df_animals$region))-1),
    # lambda_species_raw = rep(0, length(levels(df_animals$species))-1),
    # gamma_species_raw = matrix(0, nrow=(modeltype!="SI"), ncol=length(levels(df_animals$species))-1),
    # lambda_sample_type_raw = array(rep(0, length(levels(df_animals$sample_type))-1)),
    # lambda_outdoor_raw = array( rep(0, length(levels(df_animals$outdoor))-1)),
    
    # age_raw = runif( n=nrow(df_animals), min=0.1, max=0.9),
    # phi = runif( 1, 0.5, 1.5 ) 
  )
}

inits_sis = function() {
  return(list(
    sigma_lambda_region = 0.25,
    sigma_lambda_species = 0.5,
    
    sigma_lambda_sample_type = 1,
    
    lambda_baseline = -2,
    mu_gamma_species = array( -2, dim=(modeltype!="SI") ),
    sigma_gamma_species = array( 4, dim=(modeltype!="SI")),
    
    # lambda_region_raw = rep(-1, length(levels(df_animals$region))-1),
    # lambda_species_raw = rep(1, length(levels(df_animals$species))-1),
    # gamma_species_raw = matrix(1, nrow=(modeltype!="SI"), ncol=length(levels(df_animals$species))-1),
    # lambda_sample_type_raw = array(rep(-1, length(levels(df_animals$sample_type))-1)),
    # lambda_outdoor_raw = array( rep(0, length(levels(df_animals$outdoor))-1)),
    # 
    age_raw = rep(0.5, nrow(df_animals)),
    phi = 0.8 ))
  
}